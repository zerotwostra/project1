import s from './Music.module.css';


const Music = () => {
    return (
        <div>
            Music
        </div>
    )
}

export default Music;
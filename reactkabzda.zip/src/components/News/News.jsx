import s from './News.module.css';


const News = () => {
    return (
        <div>
            News
        </div>
    )
}

export default News;
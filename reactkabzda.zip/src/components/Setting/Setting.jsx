import s from './Setting.module.css';


const Setting = () => {
    return (
        <div>
            Setting
        </div>
    )
}

export default Setting;
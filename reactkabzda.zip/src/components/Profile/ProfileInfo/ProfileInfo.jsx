
import s from './ProfileInfo.module.css';


const ProfileInfo = () => {
    return (
        <div>

            <div className={s.descriptionBlock}>
                <img src='https://i.pinimg.com/736x/51/bd/d0/51bdd069669cdf00d6e53942f540ad12.jpg'/>
                <img src='https://sun9-57.userapi.com/impg/Uy2C78crpEB_il-AmDesWeZaSgb4O1F2oGkAIA/-z-wvqrq7J0.jpg?size=1280x829&quality=95&sign=b724c4a420e623497e9076d9292d6e2d&c_uniq_tag=MdAIU4UVq_VFzF6T0OFCfkkX6_S4SsCzCglWYQPgpjg&type=album'/>
            </div>
        </div>
    )
}

export default ProfileInfo;